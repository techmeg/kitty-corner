    var myWindow;
    function newWindow() {
 myWindow = window.open("http://deshommesetdeschatons.tumblr.com//", "deshommes", "width=400, height=200, left=250px, top=250px, resizable=yes, scrollbars=yes, location=yes");
 myWindow.focus();
  }
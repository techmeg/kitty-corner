# sba-js

This site was created as a skills based test for the BNY Recharge IT program to demonstrate front-end skills. Most of the work was done in the space of one business day. It is not optimized for mobile at this time.
